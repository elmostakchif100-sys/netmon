package com.example.netmon

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { NetworkScreen() } } }
    }
}

private val REQUIRED = arrayOf(
    Manifest.permission.READ_PHONE_STATE,
    Manifest.permission.ACCESS_FINE_LOCATION,
)

private fun hasPermissions(context: Context) = REQUIRED.all {
    ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
}

@Composable
fun NetworkScreen() {
    val context = LocalContext.current
    var granted by remember { mutableStateOf(hasPermissions(context)) }
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { granted = hasPermissions(context) }

    LaunchedEffect(Unit) { if (!granted) launcher.launch(REQUIRED) }

    var snapshot by remember { mutableStateOf(NetworkSnapshot()) }
    val reader = remember { NetworkReader(context) }

    // تحديث القراءة كل ثانيتين
    LaunchedEffect(granted) {
        while (granted) {
            snapshot = reader.read()
            delay(2000)
        }
    }

    Column(
        Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("مراقب الشبكة", fontSize = 24.sp, fontWeight = FontWeight.Bold)

        if (!granted) {
            Text("التطبيق يحتاج صلاحيتي الهاتف والموقع لقراءة بيانات الشبكة.")
            Button(onClick = { launcher.launch(REQUIRED) }) { Text("منح الصلاحيات") }
            return@Column
        }

        if (snapshot.isLowGeneration) {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                Text(
                    "تنبيه: الهاتف على شبكة ${snapshot.generation}. غيّر وضع الشبكة إلى 4G أو 5G.",
                    Modifier.padding(16.dp)
                )
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row("نوع الشبكة", snapshot.generation)
                Row("النطاق (Band)", snapshot.band)
                Row("PCI", snapshot.pci)
                Row("RSRP", snapshot.rsrp)
                Row("SINR", snapshot.sinr)
                Row("EARFCN", snapshot.earfcn)
            }
        }

        Button(
            onClick = {
                val intent = Intent(Settings.ACTION_DATA_ROAMING_SETTINGS)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try { context.startActivity(intent) }
                catch (e: Exception) {
                    context.startActivity(
                        Intent(Settings.ACTION_WIRELESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("فتح إعدادات شبكة الجوال") }
    }
}

@Composable
private fun Row(label: String, value: String) {
    androidx.compose.foundation.layout.Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label)
        Text(value, fontWeight = FontWeight.Bold)
    }
}
