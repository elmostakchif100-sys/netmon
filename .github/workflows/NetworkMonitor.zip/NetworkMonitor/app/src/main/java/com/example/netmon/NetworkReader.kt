package com.example.netmon

import android.content.Context
import android.telephony.CellInfo
import android.telephony.CellInfoLte
import android.telephony.CellInfoNr
import android.telephony.CellIdentityNr
import android.telephony.CellSignalStrengthNr
import android.telephony.TelephonyManager
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

/** القراءة التي تُعرض على الشاشة. "—" تعني أن القيمة غير متوفرة. */
data class NetworkSnapshot(
    val generation: String = "—",   // 5G / 4G / 3G / 2G
    val band: String = "—",
    val pci: String = "—",
    val rsrp: String = "—",
    val sinr: String = "—",
    val earfcn: String = "—",
) {
    val isLowGeneration: Boolean get() = generation == "3G" || generation == "2G"
}

class NetworkReader(context: Context) {

    private val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
    private val executor = context.mainExecutor

    /** قراءة واحدة محدّثة. تحتاج صلاحيتي READ_PHONE_STATE و ACCESS_FINE_LOCATION. */
    suspend fun read(): NetworkSnapshot = try {
        val cells = withTimeoutOrNull(3000) { requestFreshCells() } ?: tm.allCellInfo.orEmpty()
        build(cells)
    } catch (e: SecurityException) {
        NetworkSnapshot()
    }

    private suspend fun requestFreshCells(): List<CellInfo> =
        suspendCancellableCoroutine { cont ->
            tm.requestCellInfoUpdate(executor, object : TelephonyManager.CellInfoCallback() {
                override fun onCellInfo(cellInfo: MutableList<CellInfo>) {
                    if (cont.isActive) cont.resume(cellInfo)
                }
                override fun onError(errorCode: Int, detail: Throwable?) {
                    if (cont.isActive) cont.resume(emptyList())
                }
            })
        }

    private fun build(cells: List<CellInfo>): NetworkSnapshot {
        val generation = generationName(tm.dataNetworkType)
        // الخلية المتصل بها فعلياً
        val cell = cells.firstOrNull { it.isRegistered && (it is CellInfoNr || it is CellInfoLte) }
            ?: return NetworkSnapshot(generation = generation)

        return when (cell) {
            is CellInfoNr -> {
                val id = cell.cellIdentity as CellIdentityNr
                val sig = cell.cellSignalStrength as CellSignalStrengthNr
                NetworkSnapshot(
                    generation = "5G",
                    band = id.bands.joinToString { "n$it" }.ifEmpty { "—" },
                    pci = valid(id.pci),
                    rsrp = valid(sig.ssRsrp, " dBm"),
                    sinr = valid(sig.ssSinr, " dB"),
                    earfcn = valid(id.nrarfcn),
                )
            }
            is CellInfoLte -> {
                val id = cell.cellIdentity
                val sig = cell.cellSignalStrength
                NetworkSnapshot(
                    generation = "4G",
                    band = id.bands.joinToString { "B$it" }.ifEmpty { "—" },
                    pci = valid(id.pci),
                    rsrp = valid(sig.rsrp, " dBm"),
                    sinr = valid(sig.rssnr, " dB"),
                    earfcn = valid(id.earfcn),
                )
            }
            else -> NetworkSnapshot(generation = generation)
        }
    }

    /** أندرويد يعيد Int.MAX_VALUE عندما لا تتوفر القيمة. */
    private fun valid(v: Int, unit: String = ""): String =
        if (v == Int.MAX_VALUE) "—" else "$v$unit"

    private fun generationName(type: Int): String = when (type) {
        TelephonyManager.NETWORK_TYPE_NR -> "5G"
        TelephonyManager.NETWORK_TYPE_LTE -> "4G"
        TelephonyManager.NETWORK_TYPE_UMTS,
        TelephonyManager.NETWORK_TYPE_HSDPA,
        TelephonyManager.NETWORK_TYPE_HSUPA,
        TelephonyManager.NETWORK_TYPE_HSPA,
        TelephonyManager.NETWORK_TYPE_HSPAP,
        TelephonyManager.NETWORK_TYPE_EVDO_0,
        TelephonyManager.NETWORK_TYPE_EVDO_A,
        TelephonyManager.NETWORK_TYPE_EVDO_B -> "3G"
        TelephonyManager.NETWORK_TYPE_GPRS,
        TelephonyManager.NETWORK_TYPE_EDGE,
        TelephonyManager.NETWORK_TYPE_CDMA,
        TelephonyManager.NETWORK_TYPE_1xRTT -> "2G"
        else -> "—"
    }
}
